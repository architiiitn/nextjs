import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Upload, FileText, MessageSquare, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const { user, logout } = useAuth();

  const navLinks = [
    { to: '/', label: 'Dashboard', icon: LayoutDashboard },
    { to: '/upload', label: 'Upload', icon: Upload },
    { to: '/chat', label: 'Chat', icon: MessageSquare },
  ];

  return (
    <div className="layout">
      <nav className="navbar">
        <Link to="/" className="navbar-brand">
          <FileText size={24} color="var(--accent-primary)" strokeWidth={2.5} />
          <span style={{ letterSpacing: '-0.02em' }}>DocProcessor</span>
        </Link>
        <div className="navbar-right">
          <div className="navbar-nav">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`nav-link ${location.pathname === link.to ? 'active' : ''}`}
              >
                <link.icon size={16} />
                {link.label}
              </Link>
            ))}
          </div>
          {user && (
            <div className="navbar-user">
              <span className="navbar-user-email">{user.name || user.email}</span>
              <button className="btn btn-secondary btn-sm" onClick={logout} title="Sign out">
                <LogOut size={14} />
                Logout
              </button>
            </div>
          )}
        </div>
      </nav>
      <main className="main-content">{children}</main>
    </div>
  );
};

export default Layout;
